$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+844468+'&oi='+392+'&ot=1&&url='+window.location, function(json){})    

});